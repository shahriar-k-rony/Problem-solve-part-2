#include <stdio.h>
int main(void){
    /* TODO: Implement Beecrowd problem 1084 exactly as per statement. */
    return 0;
}
