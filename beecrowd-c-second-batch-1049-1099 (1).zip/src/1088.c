#include <stdio.h>
int main(void){
    /* TODO: Implement Beecrowd problem 1088 exactly as per statement. */
    return 0;
}
