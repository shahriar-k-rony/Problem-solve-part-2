#include <stdio.h>
int main(void){
    /* TODO: Implement Beecrowd problem 1053 exactly as per statement. */
    return 0;
}
