#include <stdio.h>
int main(void){
    for(int i=2;i<=100;i+=2) printf("%d\n", i);
    return 0;
}
